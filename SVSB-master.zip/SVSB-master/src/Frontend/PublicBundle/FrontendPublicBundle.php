<?php

namespace Frontend\PublicBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class FrontendPublicBundle extends Bundle
{
}
